package com.learnavro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoffeeOrdersConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}
